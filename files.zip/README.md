# winstonbids.github.io

Minimalist Player Bidding Platform

Styled and structured to match the look of [lovable.dev project page](https://lovable.dev/projects/fca9fc7a-4de4-46b4-b3a1-07aa4e3e13b6).

## How to run locally

```bash
npm install
npm start
```

## How to deploy to GitHub Pages

1. Add `"homepage": "https://winstonpais04-creator.github.io/winstonbids"` to `package.json`
2. Build: `npm run build`
3. Publish `/build` to your `gh-pages` branch or use [gh-pages](https://www.npmjs.com/package/gh-pages)