import React, { useState, useEffect } from 'react';

const API = "http://localhost:5000/api";

function App() {
  const [biddings, setBiddings] = useState([]);
  const [title, setTitle] = useState("");
  const [selected, setSelected] = useState(null);
  const [playerName, setPlayerName] = useState("");
  const [playerValue, setPlayerValue] = useState("");
  const [bidAmount, setBidAmount] = useState("");
  const [bidUser, setBidUser] = useState("");

  useEffect(() => {
    fetch(`${API}/biddings`).then(res => res.json()).then(setBiddings);
  }, [selected]);

  // Create bidding
  const createBidding = () => {
    fetch(`${API}/biddings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title })
    }).then(() => setTitle("")).then(() => window.location.reload());
  };

  // Add player
  const addPlayer = () => {
    fetch(`${API}/biddings/${selected._id}/players`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: playerName, value: Number(playerValue) })
    }).then(() => {
      setPlayerName("");
      setPlayerValue("");
      window.location.reload();
    });
  };

  // Add bid
  const bidPlayer = (idx) => {
    fetch(`${API}/biddings/${selected._id}/players/${idx}/bid`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user: bidUser, amount: Number(bidAmount) })
    }).then(() => {
      setBidUser("");
      setBidAmount("");
      window.location.reload();
    });
  };

  return (
    <div style={{
      fontFamily: "monospace",
      background: "#111",
      color: "#fff",
      minHeight: "100vh",
      padding: "40px"
    }}>
      <h1 style={{ letterSpacing: "2px", fontWeight: "900" }}>WINSTONBIDS</h1>
      <nav style={{ marginBottom: 30 }}>
        <button onClick={() => setSelected(null)} style={navBtn}>Home</button>
        <button onClick={() => setSelected("create")} style={navBtn}>Create Bidding</button>
      </nav>

      {!selected && (
        <div>
          <h2 style={subHead}>Active Biddings</h2>
          {biddings.map(b => (
            <div key={b._id} style={card}>
              <span style={{ fontWeight: "bold", fontSize: 18 }}>{b.title}</span>
              <button style={navBtn} onClick={() => setSelected(b)}>Open</button>
            </div>
          ))}
        </div>
      )}

      {selected === "create" && (
        <div>
          <h2 style={subHead}>Create Bidding Column</h2>
          <input style={input} value={title} onChange={e => setTitle(e.target.value)} placeholder="Enter column title" />
          <button style={navBtn} onClick={createBidding}>Create</button>
        </div>
      )}

      {selected && selected !== "create" && (
        <div>
          <h2 style={subHead}>{selected.title}</h2>
          <h3 style={{ fontWeight: 400, marginBottom: 10 }}>Add Player</h3>
          <input style={input} value={playerName} onChange={e => setPlayerName(e.target.value)} placeholder="Player name" />
          <input style={input} value={playerValue} type="number" onChange={e => setPlayerValue(e.target.value)} placeholder="Value Points" />
          <button style={navBtn} onClick={addPlayer}>Add</button>
          <hr style={{ border: "1px solid #222", margin: "30px 0" }} />
          <h3 style={{ fontWeight: 400 }}>Players</h3>
          {selected.players.map((p, idx) => (
            <div key={idx} style={card}>
              <div>
                <span style={{ fontWeight: "bold" }}>{p.name}</span> (Value: {p.value})
              </div>
              <div>
                <input style={input} value={bidUser} onChange={e => setBidUser(e.target.value)} placeholder="Your name" />
                <input style={input} value={bidAmount} type="number" onChange={e => setBidAmount(e.target.value)} placeholder="Bid amount" />
                <button style={navBtn} onClick={() => bidPlayer(idx)}>Bid</button>
              </div>
              <div style={{ marginTop: 10 }}>
                <span style={{ fontSize: 12, letterSpacing: "1px" }}>Bids:</span>
                {p.bids.map((b, i) => (
                  <div key={i} style={{ fontSize: 13, marginLeft: 10 }}>
                    <strong>{b.user}</strong> — {b.amount}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const navBtn = {
  background: "#fff",
  color: "#111",
  border: "none",
  padding: "7px 18px",
  margin: "0 7px",
  fontSize: 16,
  fontWeight: "bold",
  borderRadius: "3px",
  cursor: "pointer",
  letterSpacing: "1px"
};

const input = {
  background: "#222",
  color: "#fff",
  border: "none",
  borderBottom: "1px solid #444",
  margin: "0 7px 7px 0",
  padding: "8px 12px",
  fontSize: 16,
  borderRadius: "3px",
  outline: "none"
};

const card = {
  background: "#222",
  margin: "20px 0",
  padding: "20px",
  borderRadius: "8px",
  boxShadow: "0 2px 10px #0002"
};

const subHead = {
  fontWeight: "700",
  fontSize: 22,
  letterSpacing: "2px"
};

export default App;