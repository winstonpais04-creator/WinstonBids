import React, { useState } from "react";
import "./App.css";

const initialBiddings = [
  {
    title: "Sample Auction",
    players: [
      {
        name: "Jade Harper",
        value: 100,
        bids: [{ user: "Win", amount: 110 }]
      }
    ]
  }
];

export default function App() {
  const [biddings, setBiddings] = useState(initialBiddings);
  const [view, setView] = useState("home"); // home | create | column
  const [newCol, setNewCol] = useState("");
  const [activeCol, setActiveCol] = useState(null);

  // Create new bidding column
  function createColumn() {
    if (!newCol.trim()) return;
    setBiddings([...biddings, { title: newCol, players: [] }]);
    setNewCol("");
    setView("home");
  }

  // Add player
  function addPlayer(name, value) {
    if (!name || !value) return;
    const updated = { ...activeCol };
    updated.players.push({ name, value: parseInt(value), bids: [] });
    setBiddings(biddings.map(b => b.title === updated.title ? updated : b));
    setActiveCol(updated);
  }

  // Bid on player
  function bidPlayer(idx, user, amount) {
    if (!user || !amount) return;
    const updated = { ...activeCol };
    updated.players[idx].bids.push({ user, amount: parseInt(amount) });
    setBiddings(biddings.map(b => b.title === updated.title ? updated : b));
    setActiveCol(updated);
  }

  return (
    <main className="container">
      <header className="brand-header">
        <span className="badge">winstonbids.github.io</span>
        <h1 className="main-title">WINSTONBIDS</h1>
        <p className="subtitle">Minimalist Player Bidding Platform</p>
      </header>
      <div className="card">
        {view === "home" && (
          <>
            <div style={{ marginBottom: 32 }}>
              <button className="cta" onClick={() => setView("create")}>
                + Create Bidding Column
              </button>
            </div>
            <h2 className="section-title">Active Columns</h2>
            <ul className="column-list">
              {biddings.map(b => (
                <li key={b.title}>
                  <button
                    className="column-btn"
                    onClick={() => {
                      setActiveCol(b);
                      setView("column");
                    }}
                  >
                    <span className="col-title">{b.title}</span>
                    <span className="col-sub">{b.players.length} players</span>
                  </button>
                </li>
              ))}
            </ul>
          </>
        )}

        {view === "create" && (
          <div>
            <h2 className="section-title">New Bidding Column</h2>
            <input
              className="input"
              placeholder="Column Title"
              value={newCol}
              onChange={e => setNewCol(e.target.value)}
            />
            <button className="cta" onClick={createColumn}>
              Create
            </button>
          </div>
        )}

        {view === "column" && activeCol && (
          <>
            <button className="back-link" onClick={() => setView("home")}>
              ← Back
            </button>
            <h2 className="section-title">{activeCol.title}</h2>
            <AddPlayerForm onAdd={addPlayer} />
            <div style={{ marginTop: 32 }}>
              <h3 className="section-title">Players</h3>
              <ul className="player-list">
                {activeCol.players.map((p, idx) => (
                  <li key={p.name} className="player-card">
                    <div>
                      <span className="player-name">{p.name}</span>
                      <span className="player-value">
                        Value: <b>{p.value}</b>
                      </span>
                    </div>
                    <BidForm
                      onBid={(user, amount) => bidPlayer(idx, user, amount)}
                    />
                    <div className="bid-list">
                      {p.bids.length === 0 ? (
                        <span className="dim">No bids yet</span>
                      ) : (
                        p.bids.map((b, i) => (
                          <div key={i}>
                            <span className="bid-user">{b.user}</span>
                            <span className="bid-amount">{b.amount}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}
      </div>
      <footer className="footer">
        <span>Powered by Winston</span>
      </footer>
    </main>
  );
}

// AddPlayerForm
function AddPlayerForm({ onAdd }) {
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  return (
    <div className="add-form">
      <input
        className="input"
        placeholder="Player Name"
        value={name}
        onChange={e => setName(e.target.value)}
      />
      <input
        className="input"
        type="number"
        min="1"
        placeholder="Value Points"
        value={value}
        onChange={e => setValue(e.target.value)}
      />
      <button
        className="cta"
        onClick={() => {
          onAdd(name, value);
          setName("");
          setValue("");
        }}
      >
        Add Player
      </button>
    </div>
  );
}

// BidForm
function BidForm({ onBid }) {
  const [user, setUser] = useState("");
  const [amount, setAmount] = useState("");
  return (
    <div className="bid-form">
      <input
        className="input"
        placeholder="Your Name"
        value={user}
        onChange={e => setUser(e.target.value)}
        style={{ width: 80 }}
      />
      <input
        className="input"
        type="number"
        min="1"
        placeholder="Bid Amount"
        value={amount}
        onChange={e => setAmount(e.target.value)}
        style={{ width: 80 }}
      />
      <button
        className="cta"
        onClick={() => {
          onBid(user, amount);
          setUser("");
          setAmount("");
        }}
      >
        Bid
      </button>
    </div>
  );
}