const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/winstonbids', { useNewUrlParser: true, useUnifiedTopology: true });

const BiddingSchema = new mongoose.Schema({
  title: String,
  players: [{
    name: String,
    value: Number,
    bids: [{ user: String, amount: Number }]
  }]
});

const Bidding = mongoose.model('Bidding', BiddingSchema);

// Get all bidding columns
app.get('/api/biddings', async (req, res) => {
  const biddings = await Bidding.find();
  res.json(biddings);
});

// Create a bidding column
app.post('/api/biddings', async (req, res) => {
  const { title } = req.body;
  const bidding = new Bidding({ title, players: [] });
  await bidding.save();
  res.json(bidding);
});

// Add player to bidding column
app.post('/api/biddings/:id/players', async (req, res) => {
  const { name, value } = req.body;
  const bidding = await Bidding.findById(req.params.id);
  bidding.players.push({ name, value, bids: [] });
  await bidding.save();
  res.json(bidding);
});

// Add bid to player
app.post('/api/biddings/:biddingId/players/:playerIdx/bid', async (req, res) => {
  const { user, amount } = req.body;
  const bidding = await Bidding.findById(req.params.biddingId);
  bidding.players[req.params.playerIdx].bids.push({ user, amount });
  await bidding.save();
  res.json(bidding.players[req.params.playerIdx]);
});

app.listen(5000, () => console.log('Server running on 5000'));